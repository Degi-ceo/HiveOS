---
name: config-surgeon
description: Safely edits Hive's own config/AI files with validate-snapshot-test-rollback. Use whenever changing settings.json, .env schema, model strings, or any config that could break HiveOS.
---
# Config Surgeon

When changing any of Hive's own config:
1. Snapshot: record current file + current git HEAD.
2. Validate: parse JSON/YAML; confirm required keys exist.
3. Apply the minimal change in a worktree (never live).
4. Health-check: `python -m scripts.ping` and `python -m py_compile` must pass.
5. On failure: restore the snapshot, record what broke in memory, retry once.
6. On success: route through core/self_mod.py to open a PR. Never merge.
Never edit SOUL.md or the approval gate here — those are human-only.
