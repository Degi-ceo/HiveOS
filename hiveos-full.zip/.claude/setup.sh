#!/usr/bin/env bash
# Claude Code web / Codex cloud setup — runs on clone into the VM.
set -euo pipefail
python3 -m pip install --upgrade pip
pip install -r requirements.txt
mkdir -p data vault
[ -f .env ] || cp .env.example .env
echo "HiveOS environment ready."
